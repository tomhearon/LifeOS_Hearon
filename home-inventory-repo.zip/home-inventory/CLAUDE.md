# Notes for Claude

Conventions worth keeping when editing this repo.

## Structure
`src/App.jsx` holds the whole application. Section banners (`/* ─── SHELVES ─── */`)
mark the seams. Two adapters sit in `src/lib`: storage and the model proxy client.
Nothing else imports anything.

## Styling
Inline styles only, from constants near the bottom of `App.jsx`: `C` (colours),
`MONO`/`SANS`, `btn`, `input`, `th`, `td`, `Panel`, `Field`, `Empty`. No Tailwind,
no CSS files. Dark palette, amber accent, 3px radii, monospace for labels and
metadata, sans for content.

Two layout rules that were learned the hard way and should not be undone:
- Every full-width field needs `boxSizing: "border-box"`, or padding pushes it
  past its panel.
- Row lists use `gridTemplateColumns: "minmax(0, 1fr)"`. A grid track defaults
  to max-content, so one wide row widens every row.

## Model calls
All go through `askClaude(content, useSearch)`. Prompts ask for minified JSON
with single-letter keys and no prose; `parseJson` salvages objects from a reply
truncated mid-array. Vision prompts must return one entry per item *seen*, with
`u:1` and a locator for anything unidentifiable — never silently drop it.

## Principles the app is built on
- Never invent data. A vintage that isn't printed, an ISBN that isn't legible,
  and a book the model doesn't recognise all come back null or flagged.
- Show the reasoning. Similar-book matches say why they matched; design
  programmes say why a shelf got its rule; duplicate groups state the signal.
- Fail visibly. Errors surface their actual message rather than a generic one.
