# Home Inventory

A photo-driven inventory for a household: a book catalogue with shelf
arrangement, a cellar, and insurance-grade records for valuables. Point a
camera at a shelf or a wine rack and it reads what's there.

Built iteratively as a Claude artifact and ported here to run as a normal web
app.

## What it does

| Area | Summary |
|---|---|
| **Books** | Two-step capture: one shot of the whole bookcase for structure, then shelf-by-shelf photos for titles. ISBN lookup, barcode and cover identification, duplicate detection, covers and keywords pulled from Open Library and Google Books |
| **Shelves** | Multiple bookcases arranged by drag in a room plan. Six arrangement methods including a design pass that returns a programme per shelf. Books drag between shelves and cases. Placement from row photos, using the dividers of a cube unit to work out which cube each book is in |
| **Cellar** | Bottle recognition from rack photos: producer, region, vintage, grape. Wines plotted on an origin map |
| **Valuables** | Photo capture, serial numbers, replacement values, and a report flagging records that would fail at claim time |

Unreadable items are never silently dropped — anything the scan can see but
can't identify comes back flagged with a locator describing where it sits.

## Running it

```bash
cp .env.example .env        # add your Anthropic API key
npm install
npm run dev                 # web on :5173, model proxy on :8787
```

## What changed in the port

Two dependencies only worked inside the artifact sandbox.

**Storage.** The sandbox provided `window.storage`, capped at 5 MB per key.
`src/lib/storage.js` replaces it with IndexedDB behind the same four methods,
so `App.jsx` needed nothing but an import. The cap is gone, which means cover
images and shelf photos can be cached locally rather than re-fetched.

**Model calls.** The sandbox injected credentials into a direct call to
`api.anthropic.com`. A browser can't hold an API key safely, so
`src/lib/claude.js` posts to `/api/claude` and `server/index.js` adds the key
server-side. The request body is forwarded unchanged.

One thing gets better for free: the sandbox blocked outbound requests to
openlibrary.org and googleapis.com, so covers, keywords and summaries all fell
back to the model. Those APIs are reachable from a normal deployment, so the
direct paths — which are faster and more accurate — start working.

## Layout

```
src/App.jsx           the whole application, one file
src/lib/storage.js    IndexedDB adapter
src/lib/claude.js     client side of the model proxy
server/index.js       proxy holding the API key
```

`App.jsx` is large and deliberately dependency-light: no router, no state
library, no CSS framework. Styling is inline constants near the bottom of the
file (`C` for colour, `input`, `btn`, `td`, `th`).

## Worth knowing before extending it

- **Splitting App.jsx** is the obvious first refactor. Natural seams are marked
  with banner comments: capture, arrangement, similarity, duplicates, cellar.
- **Vision calls cap at ~1000 output tokens**, which is why the scan schema
  uses single-letter keys and caps books per photo. Raising the cap in
  `askClaude` lets you relax both.
- **Spine width is estimated** from page count where it isn't measured, so
  shelf-fill percentages are approximate.
- **Placements** are `{caseId, shelfId, pos}` on each book. Deleting a bookcase
  clears them rather than deleting books.
- **There is no server-side persistence.** Everything lives in the browser.
  Report → Start over → Copy everything as JSON is the only backup.

## Roadmap

- [ ] Split `App.jsx` into modules
- [ ] Cache cover images in IndexedDB instead of hot-linking
- [ ] Real file download for exports (the sandbox couldn't; a browser can)
- [ ] Sync across devices — currently export and merge by hand
- [ ] PWA manifest and service worker for offline use on a phone
