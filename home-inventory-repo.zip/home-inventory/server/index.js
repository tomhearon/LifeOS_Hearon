/*
 * Minimal proxy. Its only jobs are to hold the API key and to forward the
 * request body unchanged, so the client code stays identical to the sandbox
 * version. Deploy anywhere that runs Node 18+, or port the handler to a
 * serverless function.
 */
import http from "node:http";

const PORT = process.env.PORT || 8787;
const KEY = process.env.ANTHROPIC_API_KEY;

if (!KEY) {
  console.error("ANTHROPIC_API_KEY is not set. Copy .env.example to .env and fill it in.");
  process.exit(1);
}

const server = http.createServer(async (req, res) => {
  if (req.method !== "POST" || !req.url.startsWith("/api/claude")) {
    res.writeHead(404).end("Not found");
    return;
  }
  let body = "";
  req.on("data", (c) => (body += c));
  req.on("end", async () => {
    try {
      const upstream = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "content-type": "application/json",
          "x-api-key": KEY,
          "anthropic-version": "2023-06-01",
        },
        body,
      });
      const text = await upstream.text();
      res.writeHead(upstream.status, { "content-type": "application/json" }).end(text);
    } catch (err) {
      res.writeHead(502, { "content-type": "application/json" })
        .end(JSON.stringify({ error: { message: String(err?.message || err) } }));
    }
  });
});

server.listen(PORT, () => console.log(`Claude proxy on http://localhost:${PORT}`));
