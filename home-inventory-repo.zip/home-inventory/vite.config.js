import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  server: {
    // The browser never sees the API key; every model call goes through the
    // little Express server in /server.
    proxy: { "/api": "http://localhost:8787" },
  },
});
